import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;


public class XBase64 {

	public static void main(String[] args) throws TransformerConfigurationException, TransformerException, TransformerFactoryConfigurationError, SAXException, IOException, ParserConfigurationException 
	{
		ByteArrayInputStream is = new ByteArrayInputStream("<title>Java Web Services</title>".getBytes());
		Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(is);
		
		String base64 = serializeToBase64(doc);
		System.out.println(base64);
		
		Node node = parseFromBase64(base64, "utf-8");
		Transformer t = TransformerFactory.newInstance().newTransformer();
		t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		t.setOutputProperty(OutputKeys.INDENT, "yes");
		t.transform(new DOMSource(node), new StreamResult(System.out));
	}
	
	
	
	public static String serializeToBase64(Node node) throws TransformerConfigurationException, TransformerException, TransformerFactoryConfigurationError
	{
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		Transformer t = TransformerFactory.newInstance().newTransformer();
		t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		t.transform(new DOMSource(node), new StreamResult(buffer));
		return Base64.encodeBytes(buffer.toByteArray());
		
	}
	
	public static Node parseFromBase64(String base64, String encoding) throws SAXException, IOException, ParserConfigurationException
	{
		ByteArrayInputStream is = new ByteArrayInputStream(Base64.decode(base64.getBytes(encoding)));
		return  DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(is);
	}

}
