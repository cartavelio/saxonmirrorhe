<?xml version="1.0" encoding="UTF-8"?>
<!--
    
Oxygen Webhelp plugin
Copyright (c) 1998-2016 Syncro Soft SRL, Romania.  All rights reserved.
Licensed under the terms stated in the license file EULA_Webhelp.txt 
available in the base directory of this Oxygen Webhelp plugin.

-->

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  version="2.0">
  
  <xsl:import href="../dita2webhelp.xsl"/>  
  <xsl:import href="fixup.xsl"/>
  
  <!-- Enable debugging from here. --> 
  <xsl:param name="WEBHELP_DEBUG" select="false()"/>
  
  <!-- Normal Webhelp transformation, filtered. -->
  <xsl:template match="/">
    
    <xsl:variable name="topicContent">
      <xsl:apply-imports/>
    </xsl:variable>    
    
    <xsl:choose>
      <xsl:when test="$WEBHELP_DEBUG">
        <!-- This generates Invalid HTML, but is OK for debugging. -->
        <html>
          <xsl:apply-templates select="$topicContent" mode="fixup_desktop"/>                 
          <hr/>
          <h1>Original content:</h1>
          <xsl:copy-of select="$topicContent"/>                
        </html>
      </xsl:when>
      <xsl:otherwise>
        <xsl:variable name="fixedTopic">
	        <xsl:apply-templates select="$topicContent" mode="fixup_desktop"/>        
        </xsl:variable>
        <xsl:apply-templates select="$fixedTopic" mode="fixup_XHTML_NS"/>
      </xsl:otherwise>
    </xsl:choose>
  </xsl:template>
  
  <!-- Refer webhelp_topic.js that contains the redirect functionality -->
  <xsl:template name="addCustomJS">
    <xsl:param name="namespace"/>
    
    <xsl:element name="script" namespace="{$namespace}">
      <xsl:attribute name="type">text/javascript</xsl:attribute>
      <xsl:attribute name="charset">utf-8</xsl:attribute>
      <xsl:attribute name="src">
        <xsl:value-of select="concat($PATH2PROJ, 'oxygen-webhelp/resources/js/webhelp_topic.js')"/>
      </xsl:attribute>
      <xsl:comment/>
    </xsl:element>
  </xsl:template>
  
</xsl:stylesheet>