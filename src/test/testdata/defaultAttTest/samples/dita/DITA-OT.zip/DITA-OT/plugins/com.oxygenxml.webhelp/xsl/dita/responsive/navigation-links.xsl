<?xml version="1.0" encoding="UTF-8"?>
<!--
    
Oxygen Webhelp plugin
Copyright (c) 1998-2016 Syncro Soft SRL, Romania.  All rights reserved.
Licensed under the terms stated in the license file EULA_Webhelp.txt 
available in the base directory of this Oxygen Webhelp plugin.

-->
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:xs="http://www.w3.org/2001/XMLSchema" exclude-result-prefixes="xs dita-ot ditamsg"
    xmlns:dita-ot="http://dita-ot.sourceforge.net/ns/201007/dita-ot"
    xmlns="http://www.w3.org/1999/xhtml"
    xmlns:ditamsg="http://dita-ot.sourceforge.net/ns/200704/ditamsg" version="2.0">

    <!--<xsl:import href="plugin:org.dita.xhtml:xsl/dita2html-base.xsl"/>-->
    <!--<xsl:import href="plugin:org.dita.xhtml:xsl/xslhtml/dita2html5Impl.xsl"/>
    <xsl:import href="plugin:org.dita.xhtml:xsl/xslhtml/hi-d2html5.xsl"/>-->

    <xsl:import href="plugin:org.dita.xhtml:xsl/map2htmtoc/map2htmlImpl.xsl"/>

    <xsl:variable name="current-file"
        select="
            translate(if ($FILEDIR = '.') then
                $FILENAME
            else
                concat($FILEDIR, '/', $FILENAME), '\', '/')"/>
    <xsl:variable name="current-topicrefs"
        select="$input.dita.map//*[contains(@class, ' map/topicref ')][dita-ot:get-path($PATH2PROJ, .) = $current-file]"/>

    <xsl:variable name="current-topicref" select="$current-topicrefs[1]"/>

    <xsl:template match="*" mode="gen-user-sidetoc">
        <!-- TODO check classes -->

        <!-- TODO: Check for well class -->
        <div id="sidetoc">
            <!--<ul class="nav bs-docs-sidenav">-->
            <ul class="hidden-print">
                <xsl:apply-templates select="$current-topicrefs[1]" mode="toc-pull">
                    <xsl:with-param name="pathFromMaplist" select="$PATH2PROJ" as="xs:string"/>
                    <xsl:with-param name="children" as="element()*">
                        <xsl:apply-templates
                            select="$current-topicrefs[1]/*[contains(@class, ' map/topicref ')]"
                            mode="toc">
                            <xsl:with-param name="pathFromMaplist" select="$PATH2PROJ"
                                as="xs:string"/>
                        </xsl:apply-templates>
                    </xsl:with-param>
                </xsl:apply-templates>
            </ul>
        </div>

    </xsl:template>

    <!-- Navigation -->
    <xsl:template match="*[contains(@class, ' map/map ')]" mode="toc-pull">
        <xsl:param name="pathFromMaplist" select="$PATH2PROJ" as="xs:string"/>
        <xsl:param name="children" select="()" as="element()*"/>
        <xsl:param name="parent" select="parent::*" as="element()?"/>
        <xsl:copy-of select="$children"/>
    </xsl:template>

    <xsl:template match="*" mode="toc-pull" priority="-10">
        <xsl:param name="pathFromMaplist" as="xs:string"/>
        <xsl:param name="children" select="()" as="element()*"/>
        <xsl:param name="parent" select="parent::*" as="element()?"/>
        <xsl:apply-templates select="$parent" mode="toc-pull">
            <xsl:with-param name="pathFromMaplist" select="$pathFromMaplist"/>
            <xsl:with-param name="children" select="$children"/>
        </xsl:apply-templates>
    </xsl:template>

    <xsl:template
        match="
            *[contains(@class, ' map/topicref ')]
            [not(@toc = 'no')]
            [not(@processing-role = 'resource-only')]"
        mode="toc-pull" priority="10">

        <xsl:param name="pathFromMaplist" as="xs:string"/>
        <xsl:param name="children" select="()" as="element()*"/>
        <xsl:param name="parent" select="parent::*" as="element()?"/>

        <xsl:variable name="title">
            <xsl:apply-templates select="." mode="get-navtitle"/>
        </xsl:variable>

        <xsl:apply-templates select="$parent" mode="toc-pull">
            <xsl:with-param name="pathFromMaplist" select="$pathFromMaplist"/>
            <xsl:with-param name="children" as="element()*">
                <xsl:apply-templates
                    select="preceding-sibling::*[contains(@class, ' map/topicref ')]" mode="toc">
                    <xsl:with-param name="pathFromMaplist" select="$pathFromMaplist"/>
                </xsl:apply-templates>
                <xsl:choose>
                    <xsl:when test="normalize-space($title)">
                        <li>
                            <xsl:variable name="isActive" select=". is $current-topicref"/>
                            <xsl:if test="$isActive">
                                <xsl:attribute name="class">active</xsl:attribute>
                            </xsl:if>
                            
                            <!-- Compute the href attribute -->
                            <xsl:variable name="hrefAttr" as="attribute()">
                                <xsl:call-template name="computeHrefAttr"/>
                            </xsl:variable>
                            
                            <span class="topicref">
                                <xsl:choose>
                                    <xsl:when test="not($isActive) and normalize-space($hrefAttr)">
                                        <a>
                                            <xsl:attribute name="href">
                                                <xsl:if test="not(@scope = 'external')">
                                                  <xsl:value-of select="$pathFromMaplist"/>
                                                </xsl:if>
                                                <xsl:choose>
                                                  <xsl:when
                                                  test="
                                                            @copy-to and not(contains(@chunk, 'to-content')) and
                                                            (not(@format) or @format = 'dita' or @format = 'ditamap')">
                                                  <xsl:call-template name="replace-extension">
                                                  <xsl:with-param name="filename" select="@copy-to"/>
                                                  <xsl:with-param name="extension" select="$OUTEXT"
                                                  />
                                                  </xsl:call-template>
                                                  <xsl:if
                                                  test="not(contains(@copy-to, '#')) and contains($hrefAttr, '#')">
                                                  <xsl:value-of
                                                      select="concat('#', substring-after($hrefAttr, '#'))"
                                                  />
                                                  </xsl:if>
                                                  </xsl:when>
                                                  <xsl:when
                                                  test="not(@scope = 'external') and (not(@format) or @format = 'dita' or @format = 'ditamap')">
                                                  <xsl:call-template name="replace-extension">
                                                      <xsl:with-param name="filename" select="$hrefAttr"/>
                                                  <xsl:with-param name="extension" select="$OUTEXT"
                                                  />
                                                  </xsl:call-template>
                                                  </xsl:when>
                                                  <xsl:otherwise>
                                                      <xsl:value-of select="$hrefAttr"/>
                                                  </xsl:otherwise>
                                                </xsl:choose>
                                            </xsl:attribute>
                                            <xsl:value-of select="$title"/>
                                        </a>
                                    </xsl:when>
                                    <xsl:otherwise>
                                        <xsl:value-of select="$title"/>
                                    </xsl:otherwise>
                                </xsl:choose>
                            </span>
                            <xsl:if test="exists($children)">
                                <ul class="nav nav-list">
                                    <xsl:copy-of select="$children"/>
                                </ul>
                            </xsl:if>
                        </li>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:apply-templates select="*[contains(@class, ' map/topicref ')]"
                            mode="toc">
                            <xsl:with-param name="pathFromMaplist" select="$pathFromMaplist"/>
                        </xsl:apply-templates>
                    </xsl:otherwise>
                </xsl:choose>
                <xsl:apply-templates
                    select="following-sibling::*[contains(@class, ' map/topicref ')]" mode="toc">
                    <xsl:with-param name="pathFromMaplist" select="$pathFromMaplist"/>
                </xsl:apply-templates>
            </xsl:with-param>
        </xsl:apply-templates>
    </xsl:template>
    
    <!-- Compute the href attribute to be used when compute link to topic  -->
    <xsl:template name="computeHrefAttr">
        <xsl:choose>
            <xsl:when test="@href">
                <xsl:copy-of select="@href"/>
            </xsl:when>
            <xsl:otherwise>
                <xsl:copy-of select="*[contains(@class, 'map/topicref')][1]/@href"/>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:template match="*" mode="toc" priority="-10">
        <xsl:param name="pathFromMaplist" as="xs:string"/>
        <xsl:apply-templates select="*[contains(@class, ' map/topicref ')]" mode="toc">
            <xsl:with-param name="pathFromMaplist" select="$pathFromMaplist"/>
        </xsl:apply-templates>
    </xsl:template>

    <xsl:template
        match="
            *[contains(@class, ' map/topicref ')]
            [not(@toc = 'no')]
            [not(@processing-role = 'resource-only')]"
        mode="toc" priority="10">
        <xsl:param name="pathFromMaplist" as="xs:string"/>
        <xsl:variable name="title">
            <xsl:apply-templates select="." mode="get-navtitle"/>
        </xsl:variable>

        <xsl:choose>
            <xsl:when test="normalize-space($title)">
                <li>
                    <xsl:variable name="isActive" select=". is $current-topicref"/>
                    <xsl:if test="$isActive">
                        <xsl:attribute name="class">active</xsl:attribute>
                    </xsl:if>                    
                    <span class="topicref">
                        <xsl:variable name="hrefAttr" as="attribute()">
                            <xsl:call-template name="computeHrefAttr"/>
                        </xsl:variable>
                        <xsl:choose>
                            <xsl:when test="not($isActive) and normalize-space($hrefAttr)">
                                <a>
                                    <xsl:attribute name="href">
                                        <xsl:if test="not(@scope = 'external')">
                                            <xsl:value-of select="$pathFromMaplist"/>
                                        </xsl:if>
                                        <xsl:choose>
                                            <xsl:when
                                                test="
                                                    @copy-to and not(contains(@chunk, 'to-content')) and
                                                    (not(@format) or @format = 'dita' or @format = 'ditamap')">
                                                <xsl:call-template name="replace-extension">
                                                  <xsl:with-param name="filename" select="@copy-to"/>
                                                  <xsl:with-param name="extension" select="$OUTEXT"
                                                  />
                                                </xsl:call-template>
                                                <xsl:if
                                                    test="not(contains(@copy-to, '#')) and contains($hrefAttr, '#')">
                                                  <xsl:value-of
                                                      select="concat('#', substring-after($hrefAttr, '#'))"
                                                  />
                                                </xsl:if>
                                            </xsl:when>
                                            <xsl:when
                                                test="not(@scope = 'external') and (not(@format) or @format = 'dita' or @format = 'ditamap')">
                                                <xsl:call-template name="replace-extension">
                                                    <xsl:with-param name="filename" select="$hrefAttr"/>
                                                  <xsl:with-param name="extension" select="$OUTEXT"
                                                  />
                                                </xsl:call-template>
                                            </xsl:when>
                                            <xsl:otherwise>
                                                <xsl:value-of select="$hrefAttr"/>
                                            </xsl:otherwise>
                                        </xsl:choose>
                                    </xsl:attribute>
                                    <xsl:value-of select="$title"/>
                                </a>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:value-of select="$title"/>
                            </xsl:otherwise>
                        </xsl:choose>
                    </span>
                </li>
            </xsl:when>
        </xsl:choose>
    </xsl:template>

    <!--
        Breadcrumb generation
    -->
    <xsl:template name="gen-user-breadcrumb">
        <xsl:param name="pathFromMaplist"/>
        <ol class="hidden-print">
            <xsl:apply-templates select="$current-topicrefs[1]" mode="breadcrumb-item-pull">
                <xsl:with-param name="pathFromMaplist" select="$PATH2PROJ" as="xs:string"/>
            </xsl:apply-templates>
        </ol>
    </xsl:template>

    <xsl:template match="*" mode="breadcrumb-item-pull" priority="-10">
        <xsl:param name="pathFromMaplist" as="xs:string"/>
        <xsl:apply-templates select="parent::*" mode="#current">
            <xsl:with-param name="pathFromMaplist" select="$pathFromMaplist"/>
        </xsl:apply-templates>
    </xsl:template>

    <xsl:template
        match="
            *[contains(@class, ' map/topicref ')]
            [not(@toc = 'no')]
            [not(@processing-role = 'resource-only')]"
        mode="breadcrumb-item-pull" priority="10">
        <xsl:param name="pathFromMaplist" as="xs:string"/>

        <!-- Navigate to parent -->
        <xsl:apply-templates select="parent::*" mode="#current">
            <xsl:with-param name="pathFromMaplist" select="$pathFromMaplist"/>
        </xsl:apply-templates>

        <!-- Generate a breadcrumb item for this -->
        <xsl:apply-templates select="." mode="toc">
            <xsl:with-param name="pathFromMaplist" select="$pathFromMaplist"/>
        </xsl:apply-templates>
    </xsl:template>

    <!-- Stop on map -->
    <xsl:template match="*[contains(@class, ' map/map ')]" mode="breadcrumb-item-pull"/>



    <xsl:function name="dita-ot:get-path">
        <xsl:param name="pathFromMaplist" as="xs:string"/>
        <xsl:param name="node" as="element()"/>
        <xsl:for-each select="$node[1]">
            <xsl:if test="not(@scope = 'external')">
                <xsl:call-template name="strip-leading-parent">
                    <xsl:with-param name="path" select="$pathFromMaplist"/>
                </xsl:call-template>
            </xsl:if>
            <xsl:choose>
                <xsl:when
                    test="
                        @copy-to and not(contains(@chunk, 'to-content')) and
                        (not(@format) or @format = 'dita' or @format = 'ditamap')">
                    <xsl:value-of select="@copy-to"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:value-of select="@href"/>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:for-each>
    </xsl:function>

    <xsl:template name="strip-leading-parent">
        <xsl:param name="path" as="xs:string"/>
        <xsl:choose>
            <xsl:when test="starts-with($path, '../')">
                <xsl:call-template name="strip-leading-parent">
                    <xsl:with-param name="path" select="substring($path, 4)"/>
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$path"/>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

</xsl:stylesheet>
