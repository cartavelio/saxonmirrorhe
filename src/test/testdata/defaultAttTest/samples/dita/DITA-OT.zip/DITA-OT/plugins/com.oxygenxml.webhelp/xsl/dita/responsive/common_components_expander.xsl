<?xml version="1.0" encoding="UTF-8"?>
<!--
    
Oxygen Webhelp plugin
Copyright (c) 1998-2016 Syncro Soft SRL, Romania.  All rights reserved.
Licensed under the terms stated in the license file EULA_Webhelp.txt 
available in the base directory of this Oxygen Webhelp plugin.

-->
<!-- Used to expand Webhelp components that are common to all templates: topic, search, main.  -->
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    xmlns:oxy="http://www.oxygenxml.com/functions"
    xmlns:relpath="http://dita2indesign/functions/relpath"
    xmlns="http://www.w3.org/1999/xhtml"
    exclude-result-prefixes="xs oxy relpath"
    version="2.0">
    
    <!-- Param with relative path to the logo image -->
    <xsl:param name="WEBHELP_LOGO_IMAGE_REL_PATH">
        <xsl:if test="string-length($WEBHELP_LOGO_IMAGE) > 0">
            <xsl:value-of select="relpath:getRelativePath($OUTPUTDIR, $WEBHELP_LOGO_IMAGE)"/>
        </xsl:if>
    </xsl:param>
    
    <!-- Map title -->
    <xsl:variable name="mapTitle">
        <xsl:variable 
            name="mainBookTitle" 
            select="$input.dita.map//*[contains(@class, ' bookmap/bookmap ')]/*[contains(@class, ' bookmap/booktitle ')]/*[contains(@class, ' bookmap/mainbooktitle ')]"/>
        <xsl:variable 
            name="mapTopicTitle" 
            select="$input.dita.map/*[contains(@class, ' map/map ')]/*[contains(@class, ' topic/title ')]"/>
        <xsl:variable 
            name="mapTitle" select="$input.dita.map/*[contains(@class, ' map/map ')]/@title"/>
        <xsl:choose>
            <xsl:when test="$mainBookTitle">                
                <xsl:apply-templates select="$mainBookTitle"/>                
            </xsl:when>
            <xsl:when test="$mapTopicTitle">                
                <xsl:apply-templates select="$mapTopicTitle"/>
            </xsl:when>
            <xsl:when test="$mapTitle">
                <xsl:value-of select="$mapTitle"/>
            </xsl:when>
        </xsl:choose>
    </xsl:variable>
    
    <!-- Expand 'webhelp_search_input' place holder. -->
    <xsl:template match="*[@id = 'webhelp_search_input']" mode="copy_template">
        <xsl:copy>
            <!-- Copy attributes -->
            <xsl:apply-templates select="@*" mode="#current"/>
            
            <xsl:choose>
                <xsl:when test="exists(*)">
                    <!-- Copy its children -->                    
                    <xsl:apply-templates select="node()" mode="#current"/>                    
                </xsl:when>
                <xsl:otherwise>
                    <form 
                        method="get" 
                        action="{concat($PATH2PROJ, 'search.html')}"
                        onsubmit="return executeQuery();"
                        id="searchForm">
                        <input type="search" placeholder="search" class="form-control" name="q" id="textToSearch"/>
                    </form>
                </xsl:otherwise>
            </xsl:choose>
            
        </xsl:copy>
    </xsl:template>
    
    <xsl:template match="*[@id = 'webhelp_logo']" mode="copy_template">
        <xsl:copy>
            <!-- Copy attributes -->
            <xsl:apply-templates select="@*" mode="#current"/>
            
            <xsl:choose>
                <xsl:when
                    test="string-length($WEBHELP_LOGO_IMAGE_REL_PATH) > 0 and string-length($WEBHELP_LOGO_IMAGE_TARGET_URL) > 0">
                    <a href="{$WEBHELP_LOGO_IMAGE_TARGET_URL}" target="_blank">
                        <img src="{concat($PATH2PROJ, $WEBHELP_LOGO_IMAGE_REL_PATH)}"
                            alt="{$mapTitle}"/>
                    </a>
                </xsl:when>
                <xsl:when test="string-length($WEBHELP_LOGO_IMAGE) > 0">
                    <img src="{concat($PATH2PROJ, $WEBHELP_LOGO_IMAGE_REL_PATH)}" alt="{$mapTitle}"
                    />
                </xsl:when>
            </xsl:choose>
        </xsl:copy>
    </xsl:template>
    
    <!-- Expand 'webhelp_main_title' place holder. -->
    <xsl:template match="*[@id = 'webhelp_main_title']" mode="copy_template">
        <xsl:copy>
            <!-- Copy attributes -->
            <xsl:apply-templates select="@*" mode="#current"/>
            
            <xsl:choose>
                <xsl:when test="exists($mapTitle)">
                    <xsl:value-of select="$mapTitle"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:message>Warn: Cannot get the map title.</xsl:message>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:copy>
    </xsl:template>
    
    <!-- Expand 'webhelp_copyright_information' place holder. -->
    <xsl:template match="*[@id = 'webhelp_copyright_information']" mode="copy_template">
        <xsl:copy>
            <xsl:apply-templates select="@*" mode="#current"/>
            
            <xsl:call-template name="generateWebhelpFooter"/>            
        </xsl:copy>
    </xsl:template>
    
    
    
    <!-- Utility functions -->
    <!-- 
        Merge two sequences of HTML attributes. 
        If class or style attributes are present in both sequences then the value of these attributes is merged.   
    -->
    <xsl:function name="oxy:mergeHTMLAttributes" as="attribute()*">
        <xsl:param name="parentElementName" as="xs:string"/>
        <xsl:param name="templateAttributes" as="attribute()*"/>
        <xsl:param name="ditaotAttributes" as="attribute()*"/>
        
        <xsl:choose>
            <xsl:when test="empty($templateAttributes)">
                <xsl:copy-of select="$ditaotAttributes"/>
            </xsl:when>
            
            <xsl:when test="empty($ditaotAttributes)">
                <xsl:copy-of select="$templateAttributes"/>
            </xsl:when>
            
            <xsl:otherwise>
                <xsl:variable name="mergedAttributes" as="attribute()*">
                    <xsl:variable name="templateAttrNames" select="$templateAttributes/name()"/>
                    <xsl:for-each select="$templateAttributes">
                        <!-- Test if the attribute is also included in the DITA-OT element. -->
                        <xsl:variable name="cAttr" select="."/>
                        <xsl:variable name="ditaotAttr"
                            select="$ditaotAttributes[name(.) = name($cAttr)]" as="attribute()*"/>
                        <xsl:choose>
                            <xsl:when test="exists($ditaotAttr)">
                                <xsl:choose>
                                    <!-- Union the value of class attributes -->
                                    <xsl:when test="name(.) = 'class'">
                                        <xsl:attribute name="{name(.)}">
                                            <xsl:value-of select="."/>
                                            <xsl:text> </xsl:text>
                                            <xsl:value-of select="$ditaotAttr"/>
                                        </xsl:attribute>
                                    </xsl:when>
                                    
                                    <!-- Union the value of style attributes -->
                                    <xsl:when test="name(.) = 'style'">
                                        <xsl:attribute name="{name(.)}"><xsl:value-of select="."
                                        />;<xsl:value-of select="$ditaotAttr"
                                        /></xsl:attribute>
                                    </xsl:when>
                                    <xsl:otherwise>
                                        <xsl:copy/>
                                        <xsl:message> Warning: The attribute <xsl:value-of
                                            select="name(.)"/> is present on '<xsl:value-of
                                                select="$parentElementName"/>' element in template
                                            HTML document and in the HTML document generated by
                                            DITA-OT. </xsl:message>
                                    </xsl:otherwise>
                                </xsl:choose>
                            </xsl:when>
                            <xsl:otherwise>
                                <xsl:copy/>
                            </xsl:otherwise>
                        </xsl:choose>
                    </xsl:for-each>
                </xsl:variable>
                <xsl:sequence select="$mergedAttributes"/>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:function>
    
    <xsl:template match="node() | @*" mode="copy_template">
        <xsl:copy>
            <xsl:apply-templates select="node() | @*" mode="#current"/>
        </xsl:copy>
    </xsl:template>
    
    
    <!-- Fix the href location for link elements when href value starts with {$oxygen-webhelp-resources} -->
    <xsl:template
        match="
        @*[starts-with(., '{$oxygen-webhelp-resources}')]"
        mode="copy_template" priority="10">
        <xsl:attribute name="{name()}">
            <xsl:value-of
                select="
                concat(
                $PATH2PROJ,
                'oxygen-webhelp',
                substring-after(., '{$oxygen-webhelp-resources}'))"
            />
        </xsl:attribute>
    </xsl:template>
    
    <!-- Fix the href location for link elements when href value starts with {$oxygen-webhelp} -->
    <xsl:template match="
        @*[starts-with(., '{$oxygen-webhelp-template-dir}')]" mode="copy_template"
        priority="10">
        <xsl:attribute name="{name()}">
            <xsl:value-of
                select="
                concat(
                $PATH2PROJ,
                'oxygen-webhelp/template/',
                substring-after(., '{$oxygen-webhelp-template-dir}/'))"
            />
        </xsl:attribute>
    </xsl:template>
    
    <!-- Fix the relative locations to the output directory -->
    <xsl:template match="
        @*[starts-with(., '{$oxygen-webhelp-output-dir}')]" mode="copy_template"
        priority="10">
        <xsl:attribute name="{name()}">
            <xsl:value-of
                select="
                concat(
                $PATH2PROJ,                
                substring-after(., '{$oxygen-webhelp-output-dir}/'))"
            />
        </xsl:attribute>
    </xsl:template>
</xsl:stylesheet>