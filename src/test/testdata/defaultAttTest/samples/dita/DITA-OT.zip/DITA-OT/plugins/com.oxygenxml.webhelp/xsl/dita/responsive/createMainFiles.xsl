<?xml version="1.0" encoding="UTF-8"?>
<!--
    
Oxygen Webhelp plugin
Copyright (c) 1998-2016 Syncro Soft SRL, Romania.  All rights reserved.
Licensed under the terms stated in the license file EULA_Webhelp.txt 
available in the base directory of this Oxygen Webhelp plugin.

-->

<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  xmlns:toc="http://www.oxygenxml.com/ns/webhelp/toc"
  xmlns:index="http://www.oxygenxml.com/ns/webhelp/index" xmlns:File="java:java.io.File"
  xmlns:oxygen="http://www.oxygenxml.com/functions" xmlns:d="http://docbook.org/ns/docbook"
  xmlns:xs="http://www.w3.org/2001/XMLSchema" exclude-result-prefixes="#all" version="2.0">

  <!-- Localization of text strings displayed in Webhelp output. -->
  <xsl:import href="../dita-utilities.xsl"/>
  <xsl:import href="../../localization.xsl"/>
  <xsl:import href="../../functions.xsl"/>
  <xsl:import href="../original/relpath_util.xsl"/>
  <xsl:import href="../dita_common.xsl"/>
  
  <!-- Used to expand Webhelp templates -->
  <xsl:import href="common_components_expander.xsl"/>

  <!-- The folder with the XHTML files -->
  <xsl:param name="XHTML_FOLDER"/>

  <!-- Folder with output files. -->
  <xsl:param name="OUTPUTDIR"/>

  <!-- Base folder of Webhelp module. -->
  <xsl:param name="BASEDIR"/>

  <!-- Default file extension for HTML output files. -->
  <xsl:param name="OUTEXT" select="'.html'"/>

  <!-- Language for localization of strings in output page. -->
  <xsl:param name="DEFAULTLANG">en-us</xsl:param>

  <!-- Copyright notice inserted by user that runs transform. -->
  <xsl:param name="WEBHELP_COPYRIGHT"/>

  <!-- Name of product displayed in title of email notification sent to users. -->
  <xsl:param name="WEBHELP_PRODUCT_NAME"/>
  
  <!-- The URL for the search template. -->
  <xsl:param name="WEBHELP_SEARCH_TEMPLATE_URL"/>

  <!-- 
     If this parameter is set to 'false' then the relevance stars are not 
     added anymore for the search results displayed on the Search tab.
     By default this parameter is set to true.
   -->
  <xsl:param name="WEBHELP_SEARCH_RANKING" select="'true'"/>

  <!-- Parameter used for computing the relative path of the topic. 
  	  In case of docbook, this should be empty. -->
  <xsl:param name="PATH2PROJ" select="''"/>

  <!-- The path of index.xml -->
  <xsl:param name="INDEX_XML_FILEPATH" select="'in/index.xml'"/>

  <!-- The path of toc.xml -->
  <xsl:param name="TOC_XML_FILEPATH" select="'in/toc.xml'"/>

  <!-- Custom CSS set in DITA-OT params for custom CSS. -->
  <xsl:param name="CSS" select="''"/>
  <xsl:param name="CSSPATH" select="''"/>

  <!-- CSS that is set as Webhelp skin in the DITA Webhelp transform. -->
  <xsl:param name="WEBHELP_SKIN_CSS" select="''"/>
  
  <!-- File path of image used as favicon -->
  <xsl:param name="WEBHELP_FAVICON" select="''"/>

  <!-- Custom JavaScript code set by param webhelp.head.script -->
  <xsl:param name="WEBHELP_HEAD_SCRIPT" select="''"/>

  <!-- Google Custom Search code set by param webhelp.search.script -->
  <xsl:param name="WEBHELP_SEARCH_SCRIPT" select="''"/>

  <!-- Google Custom Search code set by param webhelp.search.results -->
  <xsl:param name="WEBHELP_SEARCH_RESULT" select="''"/>

  <!-- Custom JavaScript code set by param webhelp.body.script -->
  <xsl:param name="WEBHELP_BODY_SCRIPT" select="''"/>

  <!-- Oxygen version that created the WebHelp pages. -->
  <xsl:param name="WEBHELP_VERSION"/>

  <!-- Oxygen build number that created the WebHelp pages. -->
  <xsl:param name="WEBHELP_BUILD_NUMBER"/>
  
  <!-- File path of image with the company logo. -->
  <xsl:param name="WEBHELP_LOGO_IMAGE" select="''"/>
  
  <!-- URL that will be opened when the logo image set with 
         the webhelp.logo.image parameter is clicked in the Webhelp page. -->
  <xsl:param name="WEBHELP_LOGO_IMAGE_TARGET_URL" select="''"/>
  
  <xsl:param name="WEBHELP_DEBUG_DITA_OT_OUTPUT" select="'no'"/>
  
  <xsl:param name="WEBHELP_DITAMAP_URL"/>
  
  <xsl:param name="WEBHELP_FOOTER_INCLUDE" select="'yes'"/>
  <xsl:param name="WEBHELP_FOOTER_FILE" select="''"/>
  <xsl:param name="WEBHELP_TRIAL_LICENSE" select="'no'"/>
  
  <!-- Load the DITA Map -->
  <xsl:variable name="input.dita.map" select="document($WEBHELP_DITAMAP_URL)"/>

  <!-- Loads the additional XML documents. -->
  <xsl:variable name="index" select="document(oxygen:makeURL($INDEX_XML_FILEPATH))/index:index"/>
  <!--<xsl:variable name="toc" select="document(oxygen:makeURL($TOC_XML_FILEPATH))/toc:toc"/>-->
  
  

  <xsl:template match="/">
    <xsl:call-template name="create-localization-files"/>
    <xsl:call-template name="generate-search-file"/>
  </xsl:template>

  <!-- Creates the localization files. -->
  <xsl:template name="create-localization-files">
    <xsl:variable name="jsFileName" select="'oxygen-webhelp/resources/localization/strings.js'"/>
    <xsl:variable name="jsURL"
      select="concat(File:toURI(File:new(string($OUTPUTDIR))), $jsFileName)"/>
    <xsl:variable name="phpFileName" select="'oxygen-webhelp/resources/localization/strings.php'"/>
    <xsl:variable name="phpURL"
      select="concat(File:toURI(File:new(string($OUTPUTDIR))), $phpFileName)"/>
    <xsl:for-each select="/*">
      <xsl:call-template name="generateLocalizationFiles">
        <xsl:with-param name="jsURL" select="$jsURL"/>
        <xsl:with-param name="phpURL" select="$phpURL"/>
      </xsl:call-template>
    </xsl:for-each>
  </xsl:template>

  
  <!-- 
    Creates the Search file using the given template.
  -->
  <xsl:template name="generate-search-file">
    <!-- Apply the current selected template -->    
    <xsl:variable name="wh_search_template" select="doc($WEBHELP_SEARCH_TEMPLATE_URL)"/>
    
    <xsl:variable name="output_search_URL"
      select="concat(File:toURI(File:new(string($OUTPUTDIR))), 'search.html')"/>
    
    <xsl:result-document href="{$output_search_URL}">
      <xsl:apply-templates select="$wh_search_template" mode="copy_template"/>
    </xsl:result-document>    
  </xsl:template>
  
  
  <!-- Not needed here -->
  <xsl:template name="gen-user-breadcrumb">
    <xsl:param name="pathFromMaplist"/>
  </xsl:template>
</xsl:stylesheet>

